
export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  fullDescription: string;
  category: string;
  material: string;
  images: string[];
  isFeatured: boolean;
  inStock: boolean;
  dimensions?: {
    width: number;
    height: number;
    depth?: number;
  };
  weight?: number;
  care?: string[];
}

export interface Category {
  id: string;
  name: string;
  description: string;
  image: string;
}

export const categories: Category[] = [
  {
    id: "living-room",
    name: "Living Room",
    description: "Handcrafted furniture and décor for your living space",
    image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "kitchen",
    name: "Kitchen & Dining",
    description: "Artisanal kitchen and dining room essentials",
    image: "https://images.unsplash.com/photo-1550223026-0d6fd780c560?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "decor",
    name: "Wall Décor",
    description: "Unique wall art and decorative pieces",
    image: "https://images.unsplash.com/photo-1513161455079-7dc1de15ef3e?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "lighting",
    name: "Lighting",
    description: "Handmade lamps and lighting fixtures",
    image: "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?q=80&w=800&auto=format&fit=crop"
  }
];

export const products: Product[] = [
  {
    id: "wooden-coffee-table",
    name: "Artisan Wooden Coffee Table",
    price: 499,
    description: "Handcrafted coffee table made from reclaimed oak wood",
    fullDescription: "This stunning coffee table is meticulously handcrafted from reclaimed oak wood, featuring a natural live edge and hand-rubbed oil finish. Each piece is unique with its own grain patterns and natural characteristics. The sleek metal legs provide a beautiful contrast to the warm wood top. Perfect as a centerpiece in any living room, this table combines rustic charm with modern design sensibilities.",
    category: "living-room",
    material: "Reclaimed Oak, Steel",
    images: [
      "https://images.unsplash.com/photo-1604061515026-9ae1f47a0da9?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1580480055273-228ff5388ef8?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1613545325278-f24b0cae1224?q=80&w=800&auto=format&fit=crop"
    ],
    isFeatured: true,
    inStock: true,
    dimensions: {
      width: 48,
      height: 18,
      depth: 24
    },
    weight: 45,
    care: [
      "Dust regularly with a dry cloth",
      "Clean spills immediately with a slightly damp cloth",
      "Apply furniture wax every 6 months to maintain finish",
      "Avoid placing hot items directly on surface"
    ]
  },
  {
    id: "ceramic-vase-set",
    name: "Handthrown Ceramic Vase Set",
    price: 129,
    description: "Set of three unique ceramic vases in complementary earth tones",
    fullDescription: "This beautiful set of three ceramic vases is handthrown by our master potter using traditional techniques. Each vase features a unique organic shape with subtle variations in the glazing, creating a one-of-a-kind decorative accent for your home. The complementary earth tones work harmoniously together and fit perfectly with both modern and traditional interiors. Display them together as a striking centerpiece or separately throughout your home.",
    category: "decor",
    material: "Stoneware Clay",
    images: [
      "https://images.unsplash.com/photo-1612196808214-b40b3a388a76?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1581783342308-f792dbdd27c5?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1578913685463-bb7450a3cdf6?q=80&w=800&auto=format&fit=crop"
    ],
    isFeatured: true,
    inStock: true,
    dimensions: {
      width: 5,
      height: 12
    },
    care: [
      "Hand wash only",
      "Not dishwasher safe",
      "Avoid extreme temperature changes"
    ]
  },
  {
    id: "woven-wall-hanging",
    name: "Artisanal Woven Wall Hanging",
    price: 189,
    description: "Hand-woven fiber art piece made with natural materials and dyes",
    fullDescription: "Add texture and warmth to your walls with this stunning hand-woven wall hanging. Created by our textile artist using traditional weaving techniques, each piece features intricate patterns and a beautiful combination of natural fibers including wool, cotton, and jute. The subtle color palette is achieved using plant-based dyes, ensuring each hanging is not only beautiful but also eco-friendly. This striking piece of fiber art will be a conversation starter in any room.",
    category: "decor",
    material: "Wool, Cotton, Jute, Natural Dyes",
    images: [
      "https://images.unsplash.com/photo-1577359472653-792065afa52c?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1615529328331-f8917597711f?q=80&w=800&auto=format&fit=crop"
    ],
    isFeatured: false,
    inStock: true,
    dimensions: {
      width: 24,
      height: 36
    },
    care: [
      "Dust gently with a soft brush",
      "Keep away from direct sunlight to prevent fading",
      "Spot clean only if necessary"
    ]
  },
  {
    id: "handcrafted-wooden-lamp",
    name: "Sculptural Wooden Table Lamp",
    price: 259,
    description: "Handcrafted sculptural lamp with a wooden base and linen shade",
    fullDescription: "Light up your space with this stunning sculptural table lamp. The base is meticulously hand-carved from a single piece of sustainably harvested maple wood, showcasing beautiful natural grain patterns that make each lamp unique. The organic, flowing form creates a sense of movement and natural beauty. Topped with a handmade natural linen shade that diffuses light beautifully, this lamp adds both functional lighting and artistic presence to any room. Each lamp is signed by the artisan woodworker who created it.",
    category: "lighting",
    material: "Maple Wood, Linen, Brass Hardware",
    images: [
      "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1534291652733-039788d4e3c8?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1540932239986-30128078f3c5?q=80&w=800&auto=format&fit=crop"
    ],
    isFeatured: true,
    inStock: true,
    dimensions: {
      width: 12,
      height: 22,
      depth: 12
    },
    care: [
      "Dust regularly with a soft cloth",
      "Avoid placing in direct sunlight",
      "Use a max 60W bulb or LED equivalent"
    ]
  },
  {
    id: "ceramic-dinnerware-set",
    name: "Artisanal Ceramic Dinnerware Set",
    price: 289,
    description: "Handmade 16-piece stoneware dining set with organic forms",
    fullDescription: "Elevate your dining experience with this beautiful 16-piece ceramic dinnerware set. Each piece is handthrown on a potter's wheel and finished with our signature reactive glaze that creates unique variations in color and texture, ensuring no two pieces are exactly alike. The set includes four dinner plates, four salad plates, four bowls, and four mugs in a harmonious palette of earth tones. The organic forms and subtle imperfections celebrate the handmade nature of these pieces, bringing authenticity and warmth to your table.",
    category: "kitchen",
    material: "Stoneware Clay, Food-Safe Glazes",
    images: [
      "https://images.unsplash.com/photo-1614632537190-23e4146777db?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1522273400909-fd1a8f77637e?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1567435768831-0a38e2d0388a?q=80&w=800&auto=format&fit=crop"
    ],
    isFeatured: false,
    inStock: true,
    dimensions: {
      width: 10,
      height: 10,
      depth: 10
    },
    care: [
      "Dishwasher safe, but hand washing recommended",
      "Microwave safe",
      "Avoid sudden temperature changes"
    ]
  },
  {
    id: "handwoven-throw-blanket",
    name: "Handwoven Alpaca Throw Blanket",
    price: 169,
    description: "Luxuriously soft throw blanket handwoven from sustainable alpaca wool",
    fullDescription: "Wrap yourself in the exceptional softness of our handwoven alpaca throw blanket. Each blanket is carefully crafted on traditional looms by skilled artisans using sustainable, ethically sourced alpaca wool known for its extraordinary softness, warmth, and hypoallergenic properties. The natural, undyed colors showcase the beautiful variety of alpaca wool, and the subtle herringbone pattern adds visual interest while remaining timeless. Perfect for draping over a sofa or chair, or for adding an extra layer of warmth to your bed, this throw combines luxury with sustainable craftsmanship.",
    category: "living-room",
    material: "100% Alpaca Wool",
    images: [
      "https://images.unsplash.com/photo-1544113155-76e8da180f1b?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1556156653-e5a7c69cc263?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1600369671236-e74521d4b6ad?q=80&w=800&auto=format&fit=crop"
    ],
    isFeatured: true,
    inStock: true,
    dimensions: {
      width: 50,
      height: 60
    },
    weight: 2,
    care: [
      "Dry clean only",
      "Store folded in a cool, dry place",
      "Avoid direct sunlight for extended periods"
    ]
  },
  {
    id: "handcarved-wooden-bowl",
    name: "Hand-carved Wooden Serving Bowl",
    price: 149,
    description: "Beautifully crafted serving bowl made from a single piece of walnut",
    fullDescription: "This stunning serving bowl is hand-carved from a single piece of black walnut, showcasing the wood's natural beauty and grain patterns. Each bowl is uniquely shaped by our master woodworker, who carefully follows the natural contours and character of the wood. The smooth, food-safe finish is achieved through hours of sanding and multiple applications of a beeswax and mineral oil blend. Perfect for serving salads, fruits, or as a decorative centerpiece, this bowl brings natural warmth and artistry to your table. Due to the handcrafted nature, each bowl will have slight variations in size, shape, and grain pattern.",
    category: "kitchen",
    material: "Black Walnut, Food-Safe Finish",
    images: [
      "https://images.unsplash.com/photo-1604349954774-bf7c71ee375f?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1578830610123-36b9e5bf5b7e?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1541976590-839169839108?q=80&w=800&auto=format&fit=crop"
    ],
    isFeatured: false,
    inStock: true,
    dimensions: {
      width: 12,
      height: 4,
      depth: 12
    },
    care: [
      "Hand wash only with mild soap and warm water",
      "Dry immediately after washing",
      "Periodically reapply food-safe wood oil or beeswax",
      "Not dishwasher safe"
    ]
  },
  {
    id: "macrame-plant-hanger",
    name: "Handcrafted Macramé Plant Hanger",
    price: 59,
    description: "Intricately knotted plant hanger made from natural cotton rope",
    fullDescription: "Bring a touch of bohemian style to your indoor garden with our handcrafted macramé plant hanger. Each hanger is meticulously created using traditional knotting techniques with 100% natural cotton rope. The intricate pattern showcases a combination of classic and contemporary macramé designs, creating visual interest while securely supporting your favorite potted plants. The natural cotton material complements any interior style and adds warmth and texture to your space. Hang near a window, in a corner, or group several at varying heights for a dramatic display of your plant collection.",
    category: "decor",
    material: "100% Natural Cotton Rope",
    images: [
      "https://images.unsplash.com/photo-1614590354333-c835aed1723a?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1600048897542-2a58e1b481ca?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1612835365016-d76e5e9c9312?q=80&w=800&auto=format&fit=crop"
    ],
    isFeatured: false,
    inStock: true,
    dimensions: {
      width: 8,
      height: 40
    },
    weight: 0.5,
    care: [
      "Spot clean with mild soap and water if necessary",
      "Allow to air dry completely",
      "Avoid prolonged exposure to direct sunlight"
    ]
  }
];

export const getProductById = (id: string): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getFeaturedProducts = (): Product[] => {
  return products.filter(product => product.isFeatured);
};

export const getProductsByCategory = (categoryId: string): Product[] => {
  return products.filter(product => product.category === categoryId);
};
