
import React, { useEffect, useRef } from 'react';
import ProductCard from './ProductCard';
import { Link } from 'react-router-dom';
import { getFeaturedProducts } from '../data/products';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const FeaturedProducts = () => {
  const featuredProducts = getFeaturedProducts();
  const sectionRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate title
      gsap.from('.section-title', {
        y: 30,
        opacity: 0,
        duration: 0.8,
        scrollTrigger: {
          trigger: '.section-title',
          start: 'top 80%',
        }
      });
      
      // Animate products with stagger
      gsap.from('.product-card', {
        y: 50,
        opacity: 0,
        stagger: 0.1,
        duration: 0.6,
        scrollTrigger: {
          trigger: '.products-container',
          start: 'top 75%',
        }
      });
    }, sectionRef);
    
    return () => ctx.revert();
  }, []);
  
  return (
    <section ref={sectionRef} className="py-16 bg-background">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h2 className="section-title font-serif text-3xl md:text-4xl font-medium">
            Crafted with Passion
          </h2>
          <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
            Each piece in our collection is thoughtfully designed and meticulously crafted by skilled artisans.
          </p>
        </div>
        
        <div className="products-container grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 gap-y-10">
          {featuredProducts.map(product => (
            <div key={product.id} className="product-card">
              <ProductCard product={product} />
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <Link 
            to="/shop" 
            className="btn-secondary"
          >
            View All Products
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
