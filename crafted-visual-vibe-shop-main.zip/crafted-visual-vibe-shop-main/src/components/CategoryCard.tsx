
import React from 'react';
import { Link } from 'react-router-dom';
import { Category } from '../data/products';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  return (
    <Link
      to={`/shop?category=${category.id}`}
      className="group block relative overflow-hidden rounded-lg"
    >
      {/* Image with overlay */}
      <div className="aspect-[4/3] w-full overflow-hidden">
        <img
          src={category.image}
          alt={category.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black bg-opacity-30 transition-opacity group-hover:bg-opacity-20"></div>
      </div>
      
      {/* Text overlay */}
      <div className="absolute inset-0 flex flex-col justify-end p-6">
        <h3 className="text-white text-xl md:text-2xl font-serif font-semibold drop-shadow-md">
          {category.name}
        </h3>
        <p className="text-white text-sm mt-1 max-w-xs drop-shadow-md">
          {category.description}
        </p>
        <span className="mt-3 inline-block text-white border-b border-white pb-1 text-sm font-medium group-hover:border-clay-200 transition-colors">
          Shop Collection
        </span>
      </div>
    </Link>
  );
};

export default CategoryCard;
