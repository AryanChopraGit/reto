
import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-earth-100 text-earth-800 py-12 mt-16">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Column */}
          <div className="md:col-span-1">
            <Link to="/" className="font-serif text-2xl font-semibold">
              Handcrafted
            </Link>
            <p className="mt-4 text-sm">
              Bringing artisanal quality and handmade beauty to your home since 2015.
            </p>
            <div className="flex space-x-4 mt-4">
              <a href="#" className="text-earth-800 hover:text-clay-600 transition-colors" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-earth-800 hover:text-clay-600 transition-colors" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-earth-800 hover:text-clay-600 transition-colors" aria-label="Twitter">
                <Twitter size={20} />
              </a>
            </div>
          </div>
          
          {/* Shop Links */}
          <div>
            <h3 className="font-medium text-lg mb-4">Shop</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/shop?category=living-room" className="text-sm hover:text-clay-600 transition-colors">
                  Living Room
                </Link>
              </li>
              <li>
                <Link to="/shop?category=kitchen" className="text-sm hover:text-clay-600 transition-colors">
                  Kitchen & Dining
                </Link>
              </li>
              <li>
                <Link to="/shop?category=decor" className="text-sm hover:text-clay-600 transition-colors">
                  Wall Décor
                </Link>
              </li>
              <li>
                <Link to="/shop?category=lighting" className="text-sm hover:text-clay-600 transition-colors">
                  Lighting
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Help Links */}
          <div>
            <h3 className="font-medium text-lg mb-4">Help</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/contact" className="text-sm hover:text-clay-600 transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link to="/shipping" className="text-sm hover:text-clay-600 transition-colors">
                  Shipping & Returns
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-sm hover:text-clay-600 transition-colors">
                  FAQs
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="text-sm hover:text-clay-600 transition-colors">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
          
          {/* About Links */}
          <div>
            <h3 className="font-medium text-lg mb-4">About</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/about" className="text-sm hover:text-clay-600 transition-colors">
                  Our Story
                </Link>
              </li>
              <li>
                <Link to="/about#artisans" className="text-sm hover:text-clay-600 transition-colors">
                  Our Artisans
                </Link>
              </li>
              <li>
                <Link to="/about#sustainability" className="text-sm hover:text-clay-600 transition-colors">
                  Sustainability
                </Link>
              </li>
              <li>
                <Link to="/careers" className="text-sm hover:text-clay-600 transition-colors">
                  Careers
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-earth-200 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm">
            &copy; {new Date().getFullYear()} Handcrafted. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <Link to="/terms" className="text-sm hover:text-clay-600 transition-colors">
              Terms of Service
            </Link>
            <Link to="/privacy" className="text-sm hover:text-clay-600 transition-colors">
              Privacy Policy
            </Link>
            <Link to="/sitemap" className="text-sm hover:text-clay-600 transition-colors">
              Sitemap
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
