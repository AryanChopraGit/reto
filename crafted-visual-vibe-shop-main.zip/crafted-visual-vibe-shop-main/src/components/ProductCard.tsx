
import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Heart } from 'lucide-react';
import { Product } from '../data/products';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  
  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };
  
  return (
    <div className="group relative">
      {/* Product Image with Hover Effect */}
      <div className="aspect-square overflow-hidden rounded-md bg-earth-50 mb-3 relative">
        <Link to={`/product/${product.id}`}>
          <img 
            src={product.images[0]} 
            alt={product.name}
            className="h-full w-full object-cover object-center transition-transform duration-300 group-hover:scale-105"
          />
        </Link>
        
        {/* Quick Action Buttons - inside the image container */}
        <div className="absolute inset-x-0 bottom-0 flex justify-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-3 bg-gradient-to-t from-black/50 to-transparent">
          <button 
            onClick={() => addToCart(product, 1)}
            className="bg-white bg-opacity-90 text-clay-700 p-2 rounded-full shadow-sm hover:bg-clay-600 hover:text-white transition-colors"
            aria-label="Add to cart"
          >
            <ShoppingBag size={18} />
          </button>
          <button 
            onClick={handleWishlistToggle}
            className={`${
              isInWishlist(product.id) 
                ? "bg-clay-600 text-white" 
                : "bg-white bg-opacity-90 text-clay-700"
            } p-2 rounded-full shadow-sm hover:bg-clay-600 hover:text-white transition-colors`}
            aria-label={isInWishlist(product.id) ? "Remove from wishlist" : "Add to wishlist"}
          >
            <Heart size={18} className={isInWishlist(product.id) ? "fill-current" : ""} />
          </button>
        </div>
      </div>
      
      {/* Product Info */}
      <div>
        <h3 className="text-base font-medium">
          <Link to={`/product/${product.id}`} className="hover:text-clay-600 transition-colors">
            {product.name}
          </Link>
        </h3>
        <p className="mt-1 text-sm text-muted-foreground">
          {product.description.length > 70 
            ? `${product.description.substring(0, 70)}...` 
            : product.description
          }
        </p>
        <div className="mt-1.5 flex justify-between items-center">
          <p className="font-medium">₹{product.price.toLocaleString()}</p>
          {product.material && (
            <span className="text-xs px-2 py-1 bg-earth-50 rounded-full text-clay-700">
              {product.material.split(',')[0]}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
