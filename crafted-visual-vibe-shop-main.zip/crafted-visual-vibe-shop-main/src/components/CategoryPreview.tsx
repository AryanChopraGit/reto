
import React, { useEffect, useRef } from 'react';
import { categories } from '../data/products';
import CategoryCard from './CategoryCard';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const CategoryPreview = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate section heading
      gsap.from('.category-title', {
        y: 30,
        opacity: 0,
        duration: 0.8,
        scrollTrigger: {
          trigger: '.category-title',
          start: 'top 80%',
        }
      });
      
      // Animate categories with stagger
      gsap.from('.category-card', {
        y: 40,
        opacity: 0,
        stagger: 0.15,
        duration: 0.6,
        scrollTrigger: {
          trigger: '.categories-container',
          start: 'top 75%',
        }
      });
    }, sectionRef);
    
    return () => ctx.revert();
  }, []);
  
  return (
    <section ref={sectionRef} className="py-16 bg-earth-50">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h2 className="category-title font-serif text-3xl md:text-4xl font-medium">
            Shop by Category
          </h2>
          <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
            Explore our carefully curated collections of handcrafted treasures for every space in your home.
          </p>
        </div>
        
        <div className="categories-container grid grid-cols-1 md:grid-cols-2 gap-6">
          {categories.map((category, index) => (
            <div key={category.id} className="category-card">
              <CategoryCard category={category} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryPreview;
