
import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import gsap from 'gsap';

const Hero = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate heading and text
      gsap.from(textRef.current?.querySelectorAll('.animate-item'), {
        y: 30,
        opacity: 0,
        stagger: 0.2,
        duration: 1,
        ease: "power3.out",
      });
    }, heroRef);
    
    return () => ctx.revert();
  }, []);
  
  return (
    <div 
      ref={heroRef} 
      className="relative overflow-hidden bg-earth-100"
    >
      {/* Background image with parallax effect */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=2000&auto=format&fit=crop" 
          alt="Handcrafted furniture in a living room" 
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-black bg-opacity-30"></div>
      </div>
      
      {/* Content overlay */}
      <div className="container-custom relative z-10 min-h-[85vh] flex flex-col justify-center items-start py-20">
        <div ref={textRef} className="max-w-xl text-white">
          <h1 className="animate-item font-serif text-4xl md:text-5xl lg:text-6xl font-medium leading-tight">
            Artistry in Every Detail
          </h1>
          <p className="animate-item mt-6 text-lg md:text-xl opacity-90 max-w-md">
            Discover our collection of handcrafted pieces that bring warmth, character, and artisanal quality to your home.
          </p>
          <div className="animate-item mt-8 flex space-x-4">
            <Link to="/shop" className="btn-primary">
              Shop Collection
            </Link>
            <Link to="/about" className="text-white border border-white px-6 py-3 rounded-md hover:bg-white hover:text-earth-800 transition-colors duration-300 font-medium">
              Our Story
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
