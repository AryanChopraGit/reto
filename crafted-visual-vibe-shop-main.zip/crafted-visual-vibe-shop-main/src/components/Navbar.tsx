
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, ShoppingBag, User, Search } from 'lucide-react';
import { useCart } from '../context/CartContext';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { getCartCount } = useCart();
  const navigate = useNavigate();
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
    }
  };
  
  return (
    <header className="bg-background border-b border-border py-4 sticky top-0 z-50">
      <div className="container-custom">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="font-serif text-2xl font-semibold">
            Handcrafted
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-foreground hover:text-clay-600 transition-colors">
              Home
            </Link>
            <Link to="/shop" className="text-foreground hover:text-clay-600 transition-colors">
              Shop
            </Link>
            <Link to="/about" className="text-foreground hover:text-clay-600 transition-colors">
              About
            </Link>
            <Link to="/contact" className="text-foreground hover:text-clay-600 transition-colors">
              Contact
            </Link>
          </nav>
          
          {/* Search, Cart and User Icons */}
          <div className="flex items-center space-x-4">
            {/* Search Form */}
            <form onSubmit={handleSearch} className="hidden md:flex items-center relative">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-3 py-1.5 border border-border rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-clay-600 w-40 lg:w-52"
              />
              <Search className="h-4 w-4 absolute left-2.5 text-muted-foreground" />
            </form>
            
            {/* Mobile Search Button */}
            <button 
              className="p-1 md:hidden" 
              aria-label="Search"
              onClick={() => navigate('/search?q=')}
            >
              <Search className="h-5 w-5" />
            </button>
            
            <Link to="/account" className="p-1" aria-label="Account">
              <User className="h-5 w-5" />
            </Link>
            <Link to="/cart" className="p-1 relative" aria-label="Shopping Cart">
              <ShoppingBag className="h-5 w-5" />
              {getCartCount() > 0 && (
                <span className="absolute -top-1 -right-1 bg-clay-600 text-white text-xs w-4 h-4 flex items-center justify-center rounded-full">
                  {getCartCount()}
                </span>
              )}
            </Link>
            
            {/* Mobile Menu Button */}
            <button 
              className="p-1 md:hidden" 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Menu"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-border animate-fade-in">
            <form onSubmit={handleSearch} className="mb-4 flex">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 pl-3 pr-3 py-2 border border-border rounded-l-md text-sm focus:outline-none"
              />
              <button 
                type="submit"
                className="bg-clay-600 text-white px-3 rounded-r-md"
              >
                <Search className="h-4 w-4" />
              </button>
            </form>
            <nav className="flex flex-col space-y-4">
              <Link 
                to="/" 
                className="text-foreground hover:text-clay-600 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link 
                to="/shop" 
                className="text-foreground hover:text-clay-600 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Shop
              </Link>
              <Link 
                to="/about" 
                className="text-foreground hover:text-clay-600 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                About
              </Link>
              <Link 
                to="/contact" 
                className="text-foreground hover:text-clay-600 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Contact
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navbar;
