
import React from 'react';
import { Separator } from '@/components/ui/separator';

const PrivacyPolicyPage: React.FC = () => {
  return (
    <main className="py-12">
      <div className="container-custom max-w-3xl">
        <h1 className="font-serif text-3xl font-medium mb-2">Privacy Policy</h1>
        <p className="text-muted-foreground mb-8">Last updated: April 1, 2025</p>
        
        <Separator className="mb-8" />
        
        <div className="space-y-8">
          <section>
            <h2 className="text-xl font-medium mb-4">Introduction</h2>
            <p className="text-muted-foreground">
              At Handcrafted, we respect your privacy and are committed to protecting your personal data. 
              This privacy policy explains how we collect, use, and safeguard your information when you 
              visit our website or make a purchase.
            </p>
          </section>
          
          <section>
            <h2 className="text-xl font-medium mb-4">Information We Collect</h2>
            <p className="text-muted-foreground mb-4">
              We collect personal information that you voluntarily provide to us when you register on our website, 
              express interest in obtaining information about us or our products, or otherwise contact us.
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Name, email address, shipping address, and phone number</li>
              <li>Payment information (processed securely through our payment processors)</li>
              <li>Order history and preferences</li>
              <li>Communications with our customer service team</li>
            </ul>
          </section>
          
          <section>
            <h2 className="text-xl font-medium mb-4">How We Use Your Information</h2>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>To process and fulfill your orders</li>
              <li>To send you order confirmations and updates</li>
              <li>To respond to your inquiries and provide customer support</li>
              <li>To personalize your shopping experience</li>
              <li>To send you marketing communications (with your consent)</li>
              <li>To improve our website and product offerings</li>
            </ul>
          </section>
          
          <section>
            <h2 className="text-xl font-medium mb-4">Cookie Policy</h2>
            <p className="text-muted-foreground">
              We use cookies to enhance your browsing experience, analyze site traffic, and personalize content. 
              You can set your browser to refuse cookies or alert you when cookies are being sent. However, 
              some parts of our website may not function properly without cookies.
            </p>
          </section>
          
          <section>
            <h2 className="text-xl font-medium mb-4">Data Security</h2>
            <p className="text-muted-foreground">
              We implement appropriate security measures to protect your personal information. However, 
              no method of transmission over the Internet or electronic storage is 100% secure, and we 
              cannot guarantee absolute security.
            </p>
          </section>
          
          <section>
            <h2 className="text-xl font-medium mb-4">Your Rights</h2>
            <p className="text-muted-foreground mb-4">
              Depending on your location, you may have certain rights regarding your personal information:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Right to access and receive a copy of your personal information</li>
              <li>Right to correct inaccurate information</li>
              <li>Right to request deletion of your personal information</li>
              <li>Right to restrict or object to processing</li>
              <li>Right to data portability</li>
              <li>Right to withdraw consent</li>
            </ul>
          </section>
          
          <section>
            <h2 className="text-xl font-medium mb-4">Contact Us</h2>
            <p className="text-muted-foreground">
              If you have any questions about this privacy policy or our data practices, please contact us at:
            </p>
            <p className="font-medium mt-2">privacy@handcrafted.example.com</p>
          </section>
        </div>
      </div>
    </main>
  );
};

export default PrivacyPolicyPage;
