
import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import NewsletterSignup from '../components/NewsletterSignup';

gsap.registerPlugin(ScrollTrigger);

const AboutPage = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    window.scrollTo(0, 0);
    
    const ctx = gsap.context(() => {
      // Animate sections
      gsap.utils.toArray('.animate-section').forEach((section: any) => {
        gsap.from(section, {
          y: 30,
          opacity: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
          }
        });
      });
    }, sectionRef);
    
    return () => ctx.revert();
  }, []);
  
  return (
    <main ref={sectionRef}>
      {/* Hero Section */}
      <section className="relative">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1506806732259-39c2d0268443?q=80&w=2000&auto=format&fit=crop" 
            alt="Artisan workshop" 
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        </div>
        
        <div className="container-custom relative z-10 min-h-[50vh] flex flex-col justify-center items-center py-20 text-center">
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-medium text-white leading-tight">
            Our Story
          </h1>
          <p className="mt-6 text-lg md:text-xl text-white opacity-90 max-w-xl">
            Crafting traditions, connecting artisans, and creating pieces that last a lifetime.
          </p>
        </div>
      </section>
      
      {/* Our Mission */}
      <section className="py-16 bg-background">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center animate-section">
            <h2 className="font-serif text-3xl font-medium">Our Mission</h2>
            <p className="mt-6 text-muted-foreground">
              At Handcrafted, we believe in the beauty of imperfection and the value of items made by human hands. Our mission is to preserve traditional craftsmanship while supporting artisans around the world who pour their hearts and skills into creating unique, lasting pieces.
            </p>
            <p className="mt-4 text-muted-foreground">
              We curate collections that celebrate the materials, techniques, and cultural heritage behind each creation, bringing authentic handcrafted quality to modern homes.
            </p>
          </div>
        </div>
      </section>
      
      {/* Our Journey */}
      <section className="py-16 bg-earth-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="animate-section">
              <h2 className="font-serif text-3xl font-medium">Our Journey</h2>
              <p className="mt-6 text-muted-foreground">
                Handcrafted began in 2015 when our founder, Emma, traveled through Southeast Asia and was captivated by the incredible craftsmanship she encountered. Meeting artisans who had been perfecting their skills for generations, she recognized both the beauty of their work and the challenges they faced in reaching global markets.
              </p>
              <p className="mt-4 text-muted-foreground">
                What started as a small collection of handwoven textiles has grown into a curated marketplace celebrating artisanal traditions from around the world. Today, we work directly with over 200 artisans and small workshops, ensuring fair compensation and sustainable practices while bringing their exceptional creations to discerning customers.
              </p>
            </div>
            <div className="aspect-[4/5] overflow-hidden rounded-lg animate-section">
              <img 
                src="https://images.unsplash.com/photo-1534777752607-8d6e72e2f78f?q=80&w=800&auto=format&fit=crop" 
                alt="Artisan at work" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Meet Our Artisans */}
      <section id="artisans" className="py-16 bg-background">
        <div className="container-custom">
          <div className="text-center mb-12 animate-section">
            <h2 className="font-serif text-3xl font-medium">Meet Our Artisans</h2>
            <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
              Behind every piece in our collection is a skilled maker with a unique story and expertise passed down through generations.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="animate-section">
              <div className="aspect-square overflow-hidden rounded-lg mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1556740738-b6a63e27c4df?q=80&w=800&auto=format&fit=crop" 
                  alt="Miguel, woodworker" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="font-medium text-xl">Miguel</h3>
              <p className="text-sm text-muted-foreground">Woodworker • Peru</p>
              <p className="mt-3 text-muted-foreground">
                With 30 years of experience working with reclaimed wood, Miguel creates furniture pieces that highlight the natural beauty and character of the materials.
              </p>
            </div>
            
            <div className="animate-section">
              <div className="aspect-square overflow-hidden rounded-lg mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1450297166380-cabe503887e5?q=80&w=800&auto=format&fit=crop" 
                  alt="Aisha, ceramicist" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="font-medium text-xl">Aisha</h3>
              <p className="text-sm text-muted-foreground">Ceramicist • Morocco</p>
              <p className="mt-3 text-muted-foreground">
                Aisha combines traditional Moroccan pottery techniques with contemporary designs, creating distinctive pieces glazed with colors inspired by her homeland.
              </p>
            </div>
            
            <div className="animate-section">
              <div className="aspect-square overflow-hidden rounded-lg mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1551836022-4c4c79ecde51?q=80&w=800&auto=format&fit=crop" 
                  alt="Jun, textile artist" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="font-medium text-xl">Jun</h3>
              <p className="text-sm text-muted-foreground">Textile Artist • Japan</p>
              <p className="mt-3 text-muted-foreground">
                Jun practices traditional Japanese indigo dyeing, creating textiles with intricate patterns using techniques that have been preserved for centuries.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Sustainability Section */}
      <section id="sustainability" className="py-16 bg-sage-100">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1 animate-section">
              <h2 className="font-serif text-3xl font-medium">Our Commitment to Sustainability</h2>
              <p className="mt-6 text-muted-foreground">
                We believe that handcrafted products are inherently more sustainable. Made with care and built to last, they're the antithesis of disposable consumer culture. Beyond that, we actively work to minimize our environmental impact:
              </p>
              <ul className="mt-4 space-y-2 text-muted-foreground">
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Using natural, renewable, or recycled materials whenever possible</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Partnering with artisans who employ traditional, low-impact production methods</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Minimizing packaging and using recycled/recyclable materials</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Carbon offsetting our shipping</span>
                </li>
              </ul>
            </div>
            <div className="order-1 md:order-2 aspect-square overflow-hidden rounded-lg animate-section">
              <img 
                src="https://images.unsplash.com/photo-1485550409059-9afb054cada4?q=80&w=800&auto=format&fit=crop" 
                alt="Sustainable materials" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Call to Action */}
      <section className="py-16 bg-clay-100">
        <div className="container-custom text-center animate-section">
          <h2 className="font-serif text-3xl font-medium">Experience the Handcrafted Difference</h2>
          <p className="mt-6 text-muted-foreground max-w-xl mx-auto">
            Each piece in our collection tells a story of skill, heritage, and passion. Browse our collections and bring the beauty of handcrafted treasures into your home.
          </p>
          <div className="mt-8">
            <Link to="/shop" className="btn-primary">
              Explore Our Collection
            </Link>
          </div>
        </div>
      </section>
      
      <NewsletterSignup />
    </main>
  );
};

export default AboutPage;
