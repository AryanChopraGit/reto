
import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle } from 'lucide-react';

const OrderConfirmationPage: React.FC = () => {
  const orderNumber = `ORD-${Math.floor(100000 + Math.random() * 900000)}`;
  
  return (
    <main className="py-12">
      <div className="container-custom max-w-2xl">
        <div className="text-center">
          <CheckCircle className="text-green-500 h-16 w-16 mx-auto mb-4" />
          <h1 className="font-serif text-3xl font-medium mb-2">Thank You for Your Order!</h1>
          <p className="text-muted-foreground mb-8">
            Your order has been successfully placed and will be processed soon.
          </p>
          
          <div className="border border-border rounded-lg p-8 mb-8 text-left">
            <div className="mb-6">
              <p className="text-sm text-muted-foreground">Order Number</p>
              <p className="font-medium text-lg">{orderNumber}</p>
            </div>
            
            <div className="mb-6">
              <p className="text-sm text-muted-foreground">Payment Method</p>
              <p className="font-medium">Cash on Delivery</p>
            </div>
            
            <div>
              <p className="text-sm text-muted-foreground">Estimated Delivery</p>
              <p className="font-medium">7-10 business days</p>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/" className="btn-primary">
              Back to Home
            </Link>
            <Link to="/shop" className="btn-secondary">
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    </main>
  );
};

export default OrderConfirmationPage;
