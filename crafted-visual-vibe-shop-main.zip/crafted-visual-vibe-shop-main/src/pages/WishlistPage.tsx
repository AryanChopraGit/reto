
import React from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { Card, CardContent } from '@/components/ui/card';
import { useWishlist } from '../context/WishlistContext';

const WishlistPage: React.FC = () => {
  const { wishlistItems, removeFromWishlist } = useWishlist();

  return (
    <main className="py-12">
      <div className="container-custom">
        <h1 className="font-serif text-3xl font-medium mb-8">My Wishlist</h1>
        
        {wishlistItems.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 gap-y-10">
            {wishlistItems.map(product => (
              <div key={product.id} className="relative group">
                <ProductCard product={product} />
                <button 
                  onClick={() => removeFromWishlist(product.id)}
                  className="absolute top-2 right-2 p-2 bg-white bg-opacity-90 rounded-full shadow-sm hover:bg-clay-600 hover:text-white transition-colors"
                  aria-label="Remove from wishlist"
                >
                  <Heart className="h-4 w-4 fill-current" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <Card className="text-center py-16">
            <CardContent>
              <Heart className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-medium">Your wishlist is empty</h3>
              <p className="mt-2 text-muted-foreground max-w-md mx-auto">
                Add items you love to your wishlist. Review them anytime and easily move them to your cart.
              </p>
              <Link 
                to="/shop" 
                className="btn-primary inline-block mt-6"
              >
                Continue Shopping
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </main>
  );
};

export default WishlistPage;
