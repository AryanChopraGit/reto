
import React from 'react';
import { Link } from 'react-router-dom';
import { Trash2, ChevronRight, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';

const CartPage: React.FC = () => {
  const { items, removeFromCart, updateQuantity, getCartTotal } = useCart();

  if (items.length === 0) {
    return (
      <div className="container-custom py-16 min-h-[60vh] flex flex-col items-center justify-center">
        <div className="text-center">
          <ShoppingBag className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
          <h2 className="font-serif text-2xl font-medium mb-2">Your cart is empty</h2>
          <p className="text-muted-foreground mb-6">Looks like you haven't added anything to your cart yet.</p>
          <Link to="/shop" className="btn-primary">
            Browse Products
          </Link>
        </div>
      </div>
    );
  }

  return (
    <main className="py-12">
      <div className="container-custom">
        <h1 className="font-serif text-3xl font-medium mb-8">Shopping Cart</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="rounded-lg border border-border overflow-hidden">
              <table className="w-full">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-4">Product</th>
                    <th className="text-center p-4">Quantity</th>
                    <th className="text-right p-4">Price</th>
                    <th className="text-right p-4">Remove</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item) => (
                    <tr key={item.product.id} className="border-t border-border">
                      <td className="p-4">
                        <div className="flex items-center space-x-4">
                          <div className="h-16 w-16 flex-shrink-0 rounded-md overflow-hidden bg-earth-50">
                            <img 
                              src={item.product.images[0]} 
                              alt={item.product.name} 
                              className="h-full w-full object-cover"
                            />
                          </div>
                          <div>
                            <Link 
                              to={`/product/${item.product.id}`}
                              className="font-medium hover:text-clay-600 transition-colors"
                            >
                              {item.product.name}
                            </Link>
                            <p className="text-sm text-muted-foreground mt-1">
                              Product ID: {item.product.id}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center">
                          <select
                            value={item.quantity}
                            onChange={(e) => updateQuantity(item.product.id, parseInt(e.target.value))}
                            className="border border-input rounded-md py-1 px-2 w-16 text-center"
                          >
                            {[...Array(10)].map((_, i) => (
                              <option key={i + 1} value={i + 1}>
                                {i + 1}
                              </option>
                            ))}
                          </select>
                        </div>
                      </td>
                      <td className="p-4 text-right font-medium">
                        ₹{(item.product.price * item.quantity).toLocaleString()}
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          className="text-muted-foreground hover:text-destructive transition-colors"
                          aria-label="Remove item"
                        >
                          <Trash2 size={18} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          
          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="rounded-lg border border-border p-6">
              <h2 className="font-serif text-xl font-medium mb-4">Order Summary</h2>
              
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-medium">₹{getCartTotal().toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span className="font-medium">₹0</span>
                </div>
                <div className="border-t border-border pt-4 flex justify-between">
                  <span className="font-medium">Total</span>
                  <span className="font-medium">₹{getCartTotal().toLocaleString()}</span>
                </div>
              </div>
              
              <Link
                to="/checkout"
                className="btn-primary w-full justify-center mt-6"
              >
                Proceed to Checkout
              </Link>
              
              <Link
                to="/shop"
                className="flex items-center justify-center gap-2 mt-4 text-muted-foreground hover:text-foreground transition-colors"
              >
                <ChevronRight size={16} />
                <span>Continue Shopping</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default CartPage;
