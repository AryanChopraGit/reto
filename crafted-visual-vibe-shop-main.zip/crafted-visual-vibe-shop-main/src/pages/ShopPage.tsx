
import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import { products, categories } from '../data/products';
import { Filter, SlidersHorizontal, X } from 'lucide-react';

const ShopPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [filteredProducts, setFilteredProducts] = useState(products);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  // Get the category from URL params
  const categoryParam = searchParams.get('category');
  
  // Apply filtering based on URL parameters
  useEffect(() => {
    let result = [...products];
    
    if (categoryParam) {
      result = result.filter(product => product.category === categoryParam);
    }
    
    setFilteredProducts(result);
    window.scrollTo(0, 0);
  }, [categoryParam]);
  
  // Handle category filter change
  const handleCategoryChange = (categoryId: string) => {
    if (categoryId === 'all') {
      searchParams.delete('category');
    } else {
      searchParams.set('category', categoryId);
    }
    setSearchParams(searchParams);
  };
  
  return (
    <main className="py-8">
      <div className="container-custom">
        <div className="text-center mb-10">
          <h1 className="font-serif text-3xl md:text-4xl font-medium">
            {categoryParam 
              ? categories.find(cat => cat.id === categoryParam)?.name || 'Shop'
              : 'Shop All Products'
            }
          </h1>
          <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
            {categoryParam
              ? categories.find(cat => cat.id === categoryParam)?.description || 'Browse our collection'
              : 'Discover our collection of handcrafted pieces made with care and attention to detail.'
            }
          </p>
        </div>
        
        {/* Mobile filter button */}
        <div className="lg:hidden flex justify-between items-center mb-6">
          <p className="text-sm text-muted-foreground">
            {filteredProducts.length} products
          </p>
          <button 
            onClick={() => setIsFilterOpen(true)}
            className="flex items-center text-sm font-medium gap-1.5 py-1.5 px-3 border border-input rounded-md"
          >
            <Filter size={16} />
            Filters
          </button>
        </div>
        
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters - Desktop */}
          <div className="hidden lg:block w-64 flex-shrink-0">
            <div className="sticky top-24">
              <h3 className="font-medium text-lg mb-4">Categories</h3>
              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="category" 
                    checked={!categoryParam} 
                    onChange={() => handleCategoryChange('all')}
                    className="rounded text-clay-600 focus:ring-clay-500"
                  />
                  <span>All Products</span>
                </label>
                {categories.map(category => (
                  <label key={category.id} className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="radio" 
                      name="category" 
                      checked={categoryParam === category.id} 
                      onChange={() => handleCategoryChange(category.id)}
                      className="rounded text-clay-600 focus:ring-clay-500"
                    />
                    <span>{category.name}</span>
                  </label>
                ))}
              </div>
              
              <h3 className="font-medium text-lg mt-8 mb-4">Sort By</h3>
              <select 
                className="w-full p-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-clay-400"
                defaultValue="featured"
              >
                <option value="featured">Featured</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="newest">Newest</option>
              </select>
            </div>
          </div>
          
          {/* Mobile Filter Sidebar */}
          {isFilterOpen && (
            <div className="fixed inset-0 z-50 bg-black bg-opacity-30">
              <div className="absolute right-0 top-0 bottom-0 w-80 max-w-full bg-background p-6 shadow-xl animate-slide-in">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-medium text-lg">Filters</h3>
                  <button 
                    onClick={() => setIsFilterOpen(false)}
                    className="p-1"
                  >
                    <X size={20} />
                  </button>
                </div>
                
                <h3 className="font-medium text-base mb-3">Categories</h3>
                <div className="space-y-2 mb-6">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="radio" 
                      name="category-mobile" 
                      checked={!categoryParam}
                      onChange={() => {
                        handleCategoryChange('all');
                        setIsFilterOpen(false);
                      }}
                      className="rounded text-clay-600 focus:ring-clay-500"
                    />
                    <span>All Products</span>
                  </label>
                  {categories.map(category => (
                    <label key={category.id} className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="radio" 
                        name="category-mobile" 
                        checked={categoryParam === category.id}
                        onChange={() => {
                          handleCategoryChange(category.id);
                          setIsFilterOpen(false);
                        }}
                        className="rounded text-clay-600 focus:ring-clay-500"
                      />
                      <span>{category.name}</span>
                    </label>
                  ))}
                </div>
                
                <h3 className="font-medium text-base mb-3">Sort By</h3>
                <select 
                  className="w-full p-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-clay-400"
                  defaultValue="featured"
                >
                  <option value="featured">Featured</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="newest">Newest</option>
                </select>
                
                <div className="mt-8">
                  <button 
                    onClick={() => setIsFilterOpen(false)}
                    className="btn-primary w-full justify-center"
                  >
                    Apply Filters
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Product Grid */}
          <div className="flex-grow">
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 gap-y-10">
                {filteredProducts.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <h3 className="text-lg font-medium">No products found</h3>
                <p className="mt-2 text-muted-foreground">
                  Try adjusting your filters or browse our other categories.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
};

export default ShopPage;
