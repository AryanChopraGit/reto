
import React from 'react';
import { Link } from 'react-router-dom';
import { Separator } from '@/components/ui/separator';

const SitemapPage: React.FC = () => {
  const sitemapSections = [
    {
      title: "Main Pages",
      links: [
        { name: "Home", url: "/" },
        { name: "Shop", url: "/shop" },
        { name: "About Us", url: "/about" },
        { name: "Contact", url: "/contact" },
      ]
    },
    {
      title: "Product Categories",
      links: [
        { name: "Living Room", url: "/shop?category=living-room" },
        { name: "Kitchen & Dining", url: "/shop?category=kitchen" },
        { name: "Wall Décor", url: "/shop?category=decor" },
        { name: "Lighting", url: "/shop?category=lighting" },
      ]
    },
    {
      title: "Account",
      links: [
        { name: "My Account", url: "/account" },
        { name: "Login", url: "/login" },
        { name: "Sign Up", url: "/signup" },
        { name: "Orders", url: "/account/orders" },
        { name: "Wishlist", url: "/wishlist" },
      ]
    },
    {
      title: "Shopping",
      links: [
        { name: "Cart", url: "/cart" },
        { name: "Checkout", url: "/checkout" },
      ]
    },
    {
      title: "Information",
      links: [
        { name: "FAQs", url: "/faq" },
        { name: "Shipping & Returns", url: "/shipping" },
        { name: "Privacy Policy", url: "/privacy" },
        { name: "Terms of Service", url: "/terms" },
        { name: "Careers", url: "/careers" },
      ]
    },
  ];

  return (
    <main className="py-12">
      <div className="container-custom max-w-4xl">
        <h1 className="font-serif text-3xl font-medium mb-6">Sitemap</h1>
        <Separator className="mb-8" />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-8">
          {sitemapSections.map((section, index) => (
            <div key={index}>
              <h2 className="text-lg font-medium mb-4">{section.title}</h2>
              <ul className="space-y-2">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <Link 
                      to={link.url} 
                      className="text-muted-foreground hover:text-clay-600 transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
};

export default SitemapPage;
