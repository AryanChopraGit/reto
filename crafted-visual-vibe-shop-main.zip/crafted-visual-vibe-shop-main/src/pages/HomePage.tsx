
import React, { useEffect } from 'react';
import Hero from '../components/Hero';
import FeaturedProducts from '../components/FeaturedProducts';
import CategoryPreview from '../components/CategoryPreview';
import NewsletterSignup from '../components/NewsletterSignup';

const HomePage = () => {
  // Scroll to top on page load
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  return (
    <main>
      <Hero />
      <FeaturedProducts />
      <div className="py-16 bg-background">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="font-serif text-3xl md:text-4xl font-medium">Our Story</h2>
              <p className="mt-4 text-muted-foreground">
                Every piece in our collection tells a story of skilled craftsmanship, thoughtful design, and sustainable practices. Our artisans pour their heart and soul into creating objects that bring beauty and functionality to your everyday life.
              </p>
              <p className="mt-4 text-muted-foreground">
                We believe in the value of handmade goods that are built to last and become more meaningful over time.
              </p>
            </div>
            <div className="aspect-square overflow-hidden rounded-lg">
              <img 
                src="https://images.unsplash.com/photo-1532323544230-7191fd51bc1b?q=80&w=800&auto=format&fit=crop" 
                alt="Artisan working on a wooden piece" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
      <CategoryPreview />
      <NewsletterSignup />
    </main>
  );
};

export default HomePage;
