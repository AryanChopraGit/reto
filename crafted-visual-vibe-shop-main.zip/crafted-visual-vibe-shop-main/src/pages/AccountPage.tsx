
import React from 'react';
import { Link } from 'react-router-dom';
import { User, Package, Heart, LogOut } from 'lucide-react';

const AccountPage: React.FC = () => {
  return (
    <main className="py-12">
      <div className="container-custom max-w-6xl">
        <h1 className="font-serif text-3xl font-medium mb-8">My Account</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="col-span-1">
            <div className="bg-background border border-border rounded-lg p-4 sticky top-24">
              <div className="flex items-center gap-3 pb-4 border-b border-border mb-4">
                <div className="bg-muted rounded-full p-3">
                  <User className="h-6 w-6" />
                </div>
                <div>
                  <p className="font-medium">Guest User</p>
                  <p className="text-sm text-muted-foreground">guest@example.com</p>
                </div>
              </div>
              
              <nav className="space-y-1">
                <Link to="/account" className="flex items-center gap-2 p-2 bg-muted rounded-md text-foreground">
                  <User className="h-4 w-4" />
                  <span>Profile</span>
                </Link>
                <Link to="/account/orders" className="flex items-center gap-2 p-2 text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-md transition-colors">
                  <Package className="h-4 w-4" />
                  <span>Orders</span>
                </Link>
                <Link to="/account/wishlist" className="flex items-center gap-2 p-2 text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-md transition-colors">
                  <Heart className="h-4 w-4" />
                  <span>Wishlist</span>
                </Link>
                <button className="w-full flex items-center gap-2 p-2 text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-md transition-colors">
                  <LogOut className="h-4 w-4" />
                  <span>Logout</span>
                </button>
              </nav>
            </div>
          </div>
          
          {/* Main Content */}
          <div className="col-span-1 md:col-span-3">
            <div className="bg-background border border-border rounded-lg p-6">
              <h2 className="text-xl font-medium mb-6">Profile Information</h2>
              
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">Full Name</label>
                    <input 
                      type="text" 
                      value="Guest User" 
                      className="w-full p-2 border border-input rounded-md"
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">Email Address</label>
                    <input 
                      type="email" 
                      value="guest@example.com" 
                      className="w-full p-2 border border-input rounded-md"
                      readOnly
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Shipping Address</label>
                  <textarea 
                    className="w-full p-2 border border-input rounded-md h-24"
                    placeholder="No address saved"
                    readOnly
                  />
                </div>
                
                <div>
                  <button className="btn-primary">Edit Profile</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default AccountPage;
