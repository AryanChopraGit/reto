
import React from 'react';
import { Separator } from '@/components/ui/separator';

const TermsOfServicePage: React.FC = () => {
  return (
    <main className="py-12">
      <div className="container-custom max-w-4xl">
        <h1 className="font-serif text-3xl font-medium mb-6">Terms of Service</h1>
        <Separator className="mb-8" />
        
        <div className="prose prose-earth max-w-none">
          <p className="text-lg mb-6">
            These Terms of Service ("Terms") govern your use of Handcrafted's website, services, and products. 
            By accessing or using our platform, you agree to be bound by these Terms.
          </p>
          
          <h2 className="text-xl font-medium mt-8 mb-4">1. Account Registration</h2>
          <p>
            When you create an account with us, you must provide accurate and complete information. You are responsible 
            for safeguarding your account credentials and for all activities that occur under your account.
          </p>
          
          <h2 className="text-xl font-medium mt-8 mb-4">2. Purchases and Payments</h2>
          <p>
            All prices are in Indian Rupees (₹) and inclusive of applicable taxes. Payment must be made in full before 
            order processing. We accept various payment methods including cash on delivery for eligible orders.
          </p>
          
          <h2 className="text-xl font-medium mt-8 mb-4">3. Shipping and Delivery</h2>
          <p>
            Delivery times are estimates and not guaranteed. Handcrafted is not responsible for delays caused by 
            external factors including but not limited to weather conditions, natural disasters, or carrier delays.
          </p>
          
          <h2 className="text-xl font-medium mt-8 mb-4">4. Returns and Refunds</h2>
          <p>
            Products may be returned within 14 days of delivery if in original condition. Custom or personalized items 
            cannot be returned unless defective. Refunds will be processed within 7-10 business days.
          </p>
          
          <h2 className="text-xl font-medium mt-8 mb-4">5. Intellectual Property</h2>
          <p>
            All content on our website including text, graphics, logos, images, and software is the property of 
            Handcrafted and protected by copyright laws. Unauthorized use is prohibited.
          </p>
          
          <h2 className="text-xl font-medium mt-8 mb-4">6. Privacy Policy</h2>
          <p>
            Our Privacy Policy, available on our website, details how we collect, use, and protect your personal information.
          </p>
          
          <h2 className="text-xl font-medium mt-8 mb-4">7. Changes to Terms</h2>
          <p>
            We reserve the right to modify these Terms at any time. Changes will be effective immediately upon posting 
            to our website. Your continued use of our services constitutes acceptance of these changes.
          </p>
          
          <h2 className="text-xl font-medium mt-8 mb-4">8. Governing Law</h2>
          <p>
            These Terms are governed by the laws of India. Any disputes arising from these Terms shall be subject to the 
            exclusive jurisdiction of the courts in Delhi, India.
          </p>
          
          <h2 className="text-xl font-medium mt-8 mb-4">Contact Us</h2>
          <p className="mb-12">
            If you have any questions about these Terms, please contact us at legal@handcrafted.com.
          </p>
        </div>
      </div>
    </main>
  );
};

export default TermsOfServicePage;
