
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Briefcase, Users, Heart, Globe } from 'lucide-react';

const CareersPage: React.FC = () => {
  const careers = [
    {
      id: 1,
      title: 'Product Designer',
      department: 'Design',
      location: 'Delhi, India',
      type: 'Full-time',
      description: 'We are looking for a talented Product Designer to join our team and help design beautiful, functional handcrafted products.'
    },
    {
      id: 2,
      title: 'Marketing Specialist',
      department: 'Marketing',
      location: 'Mumbai, India',
      type: 'Full-time',
      description: 'Join our Marketing team to help showcase our handcrafted products to the world through compelling storytelling and digital campaigns.'
    },
    {
      id: 3,
      title: 'Artisan Craftsperson',
      department: 'Production',
      location: 'Jaipur, India',
      type: 'Full-time',
      description: 'Skilled artisans wanted to join our production team. Create beautiful handcrafted products using traditional techniques and natural materials.'
    }
  ];

  return (
    <main className="py-12">
      <div className="container-custom max-w-5xl">
        <div className="text-center mb-16">
          <h1 className="font-serif text-3xl md:text-4xl font-medium mb-4">Join Our Team</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            At Handcrafted, we're passionate about creating beautiful, meaningful products. 
            We're always looking for talented individuals to join our growing family.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="bg-earth-50 rounded-lg p-8">
            <h2 className="font-serif text-2xl font-medium mb-4">Our Culture</h2>
            <p className="text-muted-foreground mb-6">
              We're committed to creating an environment where creativity thrives, 
              craftsmanship is valued, and every team member can grow both personally 
              and professionally.
            </p>
            
            <div className="space-y-4">
              <div className="flex gap-3">
                <Users className="h-6 w-6 text-clay-600" />
                <div>
                  <h3 className="font-medium">Collaborative Environment</h3>
                  <p className="text-sm text-muted-foreground">
                    Work alongside talented artisans and professionals who share your passion.
                  </p>
                </div>
              </div>
              
              <div className="flex gap-3">
                <Heart className="h-6 w-6 text-clay-600" />
                <div>
                  <h3 className="font-medium">Meaningful Work</h3>
                  <p className="text-sm text-muted-foreground">
                    Create products that bring joy and beauty to people's homes.
                  </p>
                </div>
              </div>
              
              <div className="flex gap-3">
                <Globe className="h-6 w-6 text-clay-600" />
                <div>
                  <h3 className="font-medium">Sustainable Practices</h3>
                  <p className="text-sm text-muted-foreground">
                    Be part of a company that values environmental responsibility.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative overflow-hidden rounded-lg">
            <img 
              src="https://images.unsplash.com/photo-1472396961693-142e6e269027" 
              alt="Our team at work" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
        
        <h2 className="font-serif text-2xl font-medium mb-6">Open Positions</h2>
        
        <div className="space-y-6">
          {careers.map(job => (
            <Card key={job.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{job.title}</CardTitle>
                    <CardDescription className="mt-1">
                      {job.department} • {job.location} • {job.type}
                    </CardDescription>
                  </div>
                  <Briefcase className="h-5 w-5 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">{job.description}</p>
                <button className="btn-secondary">Apply Now</button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </main>
  );
};

export default CareersPage;
