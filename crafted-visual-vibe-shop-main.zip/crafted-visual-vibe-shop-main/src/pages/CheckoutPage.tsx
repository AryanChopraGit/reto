import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShieldCheck, CreditCard, MapPin, PlusCircle, MinusCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useToast } from "@/components/ui/use-toast"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

const products = [
  {
    id: "prod-01",
    name: "Handwoven Cotton Throw",
    description: "A soft and cozy throw blanket perfect for adding a touch of warmth to your living space.",
    price: 2499,
    image: "/images/products/throw.jpg",
  },
  {
    id: "prod-04",
    name: "Handcarved Wooden Bowl",
    description: "A beautifully carved wooden bowl, ideal for serving snacks or as a decorative piece.",
    price: 1899,
    image: "/images/products/bowl.jpg",
  }
];

const CheckoutPage: React.FC = () => {
  const navigate = useNavigate();
  const { items, clearCart, getCartTotal } = useCart();
  const { toast } = useToast();

  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zip, setZip] = useState('');
  const [country, setCountry] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('credit-card');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string, discount: number } | null>(null);
  const [discount, setDiscount] = useState(0);

  const subtotal = getCartTotal();
  const shipping = subtotal > 5000 ? 0 : 499;
  const total = subtotal + shipping - discount;

  useEffect(() => {
    // For demonstration purposes, apply a fixed discount if a specific coupon code is entered
    if (couponCode === "DISCOUNT10" && !appliedCoupon) {
      const discountAmount = Math.min(1000, subtotal * 0.1); // 10% off, up to ₹1000
      setDiscount(discountAmount);
      setAppliedCoupon({ code: couponCode, discount: discountAmount });
      toast({
        title: "Coupon Applied",
        description: "You got 10% discount on your order!",
      });
    }
  }, [couponCode, subtotal, appliedCoupon, toast]);

  const applyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponCode === "DISCOUNT10" && !appliedCoupon) {
      const discountAmount = Math.min(1000, subtotal * 0.1); // 10% off, up to ₹1000
      setDiscount(discountAmount);
      setAppliedCoupon({ code: couponCode, discount: discountAmount });
      toast({
        title: "Coupon Applied",
        description: "You got 10% discount on your order!",
      });
    } else {
      toast({
        variant: "destructive",
        title: "Invalid Coupon",
        description: "This coupon is not valid or has already been applied.",
      });
    }
  };

  const removeAppliedCoupon = () => {
    setAppliedCoupon(null);
    setDiscount(0);
    setCouponCode('');
    toast({
      title: "Coupon Removed",
      description: "The coupon has been removed from your order.",
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate order submission
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // Clear cart and navigate to order confirmation
    clearCart();
    toast({
      title: "Order Confirmed",
      description: "Your order has been placed successfully.",
    });
    navigate('/order-confirmation');
  };

  return (
    <main className="py-12">
      <div className="container-custom">
        <h1 className="font-serif text-3xl font-medium mb-8">Checkout</h1>

        {items.length === 0 ? (
          <Card className="text-center py-16">
            <CardContent>
              <h3 className="text-xl font-medium">Your cart is empty</h3>
              <p className="mt-2 text-muted-foreground max-w-md mx-auto">
                Looks like you haven't added anything to your cart yet.
              </p>
              <Link
                to="/shop"
                className="btn-primary inline-block mt-6"
              >
                Continue Shopping
              </Link>
            </CardContent>
          </Card>
        ) : (
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Shipping Information */}
            <div className="md:col-span-1">
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-lg font-medium mb-4">Shipping Information</h2>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-muted-foreground mb-1">Full Name</label>
                      <Input
                        type="text"
                        id="name"
                        placeholder="John Doe"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="address" className="block text-sm font-medium text-muted-foreground mb-1">Address</label>
                      <Input
                        type="text"
                        id="address"
                        placeholder="123 Main St"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        required
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="city" className="block text-sm font-medium text-muted-foreground mb-1">City</label>
                        <Input
                          type="text"
                          id="city"
                          placeholder="New York"
                          value={city}
                          onChange={(e) => setCity(e.target.value)}
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="state" className="block text-sm font-medium text-muted-foreground mb-1">State</label>
                        <Input
                          type="text"
                          id="state"
                          placeholder="NY"
                          value={state}
                          onChange={(e) => setState(e.target.value)}
                          required
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="zip" className="block text-sm font-medium text-muted-foreground mb-1">ZIP Code</label>
                        <Input
                          type="text"
                          id="zip"
                          placeholder="10001"
                          value={zip}
                          onChange={(e) => setZip(e.target.value)}
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="country" className="block text-sm font-medium text-muted-foreground mb-1">Country</label>
                        <Input
                          type="text"
                          id="country"
                          placeholder="USA"
                          value={country}
                          onChange={(e) => setCountry(e.target.value)}
                          required
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Order Summary */}
            <div className="md:col-span-1">
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-lg font-medium mb-4">Order Summary</h2>
                  <div className="space-y-4">
                    {items.map((item) => (
                      <div key={item.product.id} className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="mr-4">
                            <img
                              src={item.product.images[0]}
                              alt={item.product.name}
                              className="h-16 w-16 object-cover rounded-md"
                            />
                          </div>
                          <div>
                            <p className="font-medium">{item.product.name}</p>
                            <p className="text-sm text-muted-foreground">₹{item.product.price.toLocaleString()}</p>
                            <div className="flex items-center mt-1">
                              <span className="text-sm text-muted-foreground">Qty:</span>
                              <div className="flex items-center ml-2">
                                <Button variant="ghost" size="sm" disabled>
                                  <MinusCircle className="h-4 w-4" />
                                </Button>
                                <Input
                                  type="number"
                                  value={item.quantity}
                                  className="w-16 text-center rounded-md border border-input text-sm"
                                  readOnly
                                />
                                <Button variant="ghost" size="sm" disabled>
                                  <PlusCircle className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div>
                          ₹{(item.product.price * item.quantity).toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>

                  <Separator className="my-4" />

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span>₹{subtotal.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Shipping</span>
                      <span>₹{shipping.toLocaleString()}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between text-sm text-green-600">
                        <span>Discount</span>
                        <span>- ₹{discount.toLocaleString()}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-medium mt-2 pt-2 border-t">
                      <span>Total</span>
                      <span>₹{total.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="mt-6 border-t pt-4">
                    <h3 className="text-base font-medium mb-2">Payment Method</h3>
                    <div className="space-y-2">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          value="credit-card"
                          checked={paymentMethod === 'credit-card'}
                          onChange={() => setPaymentMethod('credit-card')}
                          className="mr-2"
                        />
                        <CreditCard className="h-4 w-4 mr-2" />
                        Credit Card
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          value="cash-on-delivery"
                          checked={paymentMethod === 'cash-on-delivery'}
                          onChange={() => setPaymentMethod('cash-on-delivery')}
                          className="mr-2"
                        />
                        <ShieldCheck className="h-4 w-4 mr-2" />
                        Cash on Delivery
                      </label>
                    </div>
                  </div>

                  <div className="mt-6 border-t pt-4">
                    <h3 className="text-base font-medium mb-2">Coupon Code</h3>

                    {appliedCoupon ? (
                      <div className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-md">
                        <div>
                          <span className="font-medium text-green-700">
                            "{appliedCoupon.code}" applied
                          </span>
                          <p className="text-sm text-green-600">
                            You saved ₹{appliedCoupon.discount.toLocaleString()}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={removeAppliedCoupon}
                          className="text-sm text-red-600 hover:text-red-800 transition-colors"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <form onSubmit={applyCoupon} className="flex gap-2">
                        <input
                          type="text"
                          value={couponCode}
                          onChange={(e) => setCouponCode(e.target.value)}
                          placeholder="Enter coupon code"
                          className="flex-1 p-2 border border-input rounded-md text-sm"
                        />
                        <button
                          type="submit"
                          className="bg-clay-600 text-white px-4 py-2 rounded-md text-sm hover:bg-clay-700 transition-colors"
                        >
                          Apply
                        </button>
                      </form>
                    )}
                  </div>

                  <Button
                    type="submit"
                    className="w-full mt-6"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <svg className="animate-spin h-5 w-5 mr-2" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Placing Order...
                      </>
                    ) : (
                      <>
                        <MapPin className="h-4 w-4 mr-2" />
                        Place Order
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </form>
        )}
      </div>
    </main>
  );
};

export default CheckoutPage;
