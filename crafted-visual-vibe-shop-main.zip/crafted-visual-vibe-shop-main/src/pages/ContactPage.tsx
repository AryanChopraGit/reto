
import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { toast } from 'sonner';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically handle the form submission to your backend
    console.log('Form data:', formData);
    toast.success('Thank you for your message! We\'ll get back to you soon.');
    
    // Reset form
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  };
  
  return (
    <main className="py-8">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h1 className="font-serif text-3xl md:text-4xl font-medium">
            Contact Us
          </h1>
          <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
            Have a question or need assistance? We're here to help. Reach out to our team using the form below or contact us directly.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="bg-earth-50 p-8 rounded-lg">
            <h2 className="font-serif text-2xl font-medium mb-6">
              Get In Touch
            </h2>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="mr-4 mt-1">
                  <MapPin className="h-5 w-5 text-clay-600" />
                </div>
                <div>
                  <h3 className="font-medium">Our Location</h3>
                  <address className="not-italic text-muted-foreground mt-1">
                    123 Artisan Way<br />
                    Portland, OR 97205<br />
                    United States
                  </address>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mr-4 mt-1">
                  <Phone className="h-5 w-5 text-clay-600" />
                </div>
                <div>
                  <h3 className="font-medium">Phone</h3>
                  <p className="text-muted-foreground mt-1">
                    <a href="tel:+15035551234" className="hover:text-clay-600 transition-colors">
                      (503) 555-1234
                    </a>
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mr-4 mt-1">
                  <Mail className="h-5 w-5 text-clay-600" />
                </div>
                <div>
                  <h3 className="font-medium">Email</h3>
                  <p className="text-muted-foreground mt-1">
                    <a href="mailto:hello@handcrafted.com" className="hover:text-clay-600 transition-colors">
                      hello@handcrafted.com
                    </a>
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mr-4 mt-1">
                  <Clock className="h-5 w-5 text-clay-600" />
                </div>
                <div>
                  <h3 className="font-medium">Hours</h3>
                  <p className="text-muted-foreground mt-1">
                    Monday - Friday: 10am - 6pm<br />
                    Saturday: 11am - 5pm<br />
                    Sunday: Closed
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <h3 className="font-medium mb-3">Connect With Us</h3>
              <p className="text-muted-foreground">
                Follow us on social media for inspiration, behind-the-scenes content, and updates on new arrivals.
              </p>
              <div className="flex space-x-4 mt-4">
                <a href="#" className="bg-clay-600 text-white p-2 rounded-full hover:bg-clay-700 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-facebook"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                </a>
                <a href="#" className="bg-clay-600 text-white p-2 rounded-full hover:bg-clay-700 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-instagram"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg>
                </a>
                <a href="#" className="bg-clay-600 text-white p-2 rounded-full hover:bg-clay-700 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-pinterest"><line x1="12" x2="12" y1="8" y2="16"/><line x1="8" x2="16" y1="12" y2="12"/><circle cx="12" cy="12" r="10"/></svg>
                </a>
              </div>
            </div>
          </div>
          
          {/* Contact Form */}
          <div>
            <h2 className="font-serif text-2xl font-medium mb-6">
              Send Us a Message
            </h2>
            
            <form onSubmit={handleSubmit}>
              <div className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-2">
                      Your Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full p-3 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-clay-400"
                      required
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-2">
                      Your Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full p-3 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-clay-400"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium mb-2">
                    Subject
                  </label>
                  <select
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className="w-full p-3 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-clay-400"
                    required
                  >
                    <option value="">Select a subject</option>
                    <option value="order">Order Inquiry</option>
                    <option value="product">Product Question</option>
                    <option value="custom">Custom Order</option>
                    <option value="return">Return or Exchange</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-2">
                    Your Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={6}
                    className="w-full p-3 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-clay-400"
                    required
                  ></textarea>
                </div>
                
                <div>
                  <button type="submit" className="btn-primary">
                    Send Message
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
        
        {/* Map Section (optional) */}
        <div className="mt-16">
          <h2 className="font-serif text-2xl font-medium mb-6 text-center">
            Visit Our Showroom
          </h2>
          <div className="aspect-[16/9] bg-earth-100 rounded-lg overflow-hidden">
            {/* Replace with an actual map embed */}
            <div className="w-full h-full flex items-center justify-center bg-earth-100 text-muted-foreground">
              <p>Map Embed Goes Here</p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default ContactPage;
