
import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import { products } from '../data/products';
import { Search } from 'lucide-react';

const SearchResultsPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const [searchResults, setSearchResults] = useState(products);

  useEffect(() => {
    if (query) {
      const lowercaseQuery = query.toLowerCase();
      const filtered = products.filter(
        product => 
          product.name.toLowerCase().includes(lowercaseQuery) || 
          product.description.toLowerCase().includes(lowercaseQuery) ||
          product.material.toLowerCase().includes(lowercaseQuery)
      );
      setSearchResults(filtered);
      window.scrollTo(0, 0);
    } else {
      setSearchResults([]);
    }
  }, [query]);

  return (
    <main className="py-8">
      <div className="container-custom">
        <div className="text-center mb-10">
          <h1 className="font-serif text-3xl md:text-4xl font-medium">
            Search Results
          </h1>
          {query && (
            <p className="mt-4 text-muted-foreground">
              Showing results for: <span className="font-medium text-foreground">"{query}"</span>
            </p>
          )}
        </div>

        {searchResults.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 gap-y-10">
            {searchResults.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Search className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium">No products found</h3>
            <p className="mt-2 text-muted-foreground max-w-md mx-auto">
              {query 
                ? `We couldn't find any products matching "${query}". Try a different search term or browse our categories.`
                : 'Please enter a search term to find products.'}
            </p>
          </div>
        )}
      </div>
    </main>
  );
};

export default SearchResultsPage;
