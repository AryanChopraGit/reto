
import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQPage: React.FC = () => {
  const faqs = [
    {
      question: "How are your products made?",
      answer: "All our products are handcrafted by skilled artisans using traditional techniques. We source sustainable materials from local suppliers whenever possible and ensure fair working conditions for all our craftspeople."
    },
    {
      question: "What is your shipping policy?",
      answer: "We offer free shipping on all orders over ₹2,000 within India. Standard shipping typically takes 3-5 business days, while express shipping (available at an additional cost) takes 1-2 business days. International shipping is available to select countries."
    },
    {
      question: "How do I return a product?",
      answer: "If you're not completely satisfied with your purchase, you can return it within 30 days of delivery. The item must be unused and in its original packaging. Please visit our Returns page for detailed instructions on how to initiate a return."
    },
    {
      question: "Do you offer gift wrapping?",
      answer: "Yes, we offer gift wrapping services for a nominal fee. During checkout, you'll have the option to add gift wrapping and include a personalized message."
    },
    {
      question: "Are your products eco-friendly?",
      answer: "Sustainability is at the core of our philosophy. We use natural, renewable materials whenever possible and minimize waste in our production process. Many of our products are made from reclaimed or recycled materials."
    },
    {
      question: "How do I care for my handcrafted products?",
      answer: "Each product comes with specific care instructions. Generally, we recommend keeping wooden items away from direct sunlight and extreme temperature changes, wiping clean with a damp cloth, and periodically applying natural oils to maintain the finish."
    },
    {
      question: "Do you offer customizations?",
      answer: "Yes, we offer customization services for select products. Please contact our customer service team with your specific requirements, and we'll let you know if it's possible and provide a quote."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept major credit/debit cards, UPI payments, net banking, and cash on delivery (for orders under ₹10,000)."
    },
    {
      question: "How can I track my order?",
      answer: "Once your order ships, you'll receive a tracking number via email. You can also log into your account on our website to view the status of your order."
    },
    {
      question: "Are there any discounts for bulk orders?",
      answer: "Yes, we offer special pricing for bulk orders. Please contact our sales team at wholesale@handcrafted.example.com for more information."
    }
  ];

  return (
    <main className="py-12">
      <div className="container-custom max-w-3xl">
        <div className="text-center mb-12">
          <h1 className="font-serif text-3xl md:text-4xl font-medium mb-4">Frequently Asked Questions</h1>
          <p className="text-muted-foreground">
            Find answers to common questions about our products, shipping, returns, and more.
          </p>
        </div>
        
        <Accordion type="single" collapsible className="mb-8">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`}>
              <AccordionTrigger className="text-left font-medium">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
        
        <div className="bg-earth-50 rounded-lg p-6 text-center">
          <h3 className="font-medium mb-2">Still have questions?</h3>
          <p className="text-muted-foreground mb-4">
            Our customer support team is here to help you.
          </p>
          <a href="/contact" className="btn-secondary inline-block">
            Contact Us
          </a>
        </div>
      </div>
    </main>
  );
};

export default FAQPage;
