
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getProductById, getProductsByCategory, Product } from '../data/products';
import { Minus, Plus, ChevronRight, Heart, Share, Star, AlertCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';
import ProductCard from '../components/ProductCard';
import { toast } from 'sonner';
import gsap from 'gsap';

const ProductDetailPage = () => {
  const { productId } = useParams<{ productId: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const { addToCart } = useCart();
  
  useEffect(() => {
    if (productId) {
      const foundProduct = getProductById(productId);
      if (foundProduct) {
        setProduct(foundProduct);
        setActiveImage(0);
        setQuantity(1);
        
        // Get related products from the same category
        const related = getProductsByCategory(foundProduct.category)
          .filter(p => p.id !== productId)
          .slice(0, 4);
        setRelatedProducts(related);
        
        // Animate the product details
        const ctx = gsap.context(() => {
          gsap.from('.product-animate', {
            y: 30,
            opacity: 0,
            stagger: 0.1,
            duration: 0.6,
            ease: 'power3.out',
            clearProps: 'all',
          });
        });
        
        // Scroll to top
        window.scrollTo(0, 0);
        
        return () => ctx.revert();
      }
    }
  }, [productId]);
  
  const handleAddToCart = () => {
    if (product) {
      addToCart(product, quantity);
      toast.success(`Added ${product.name} to your cart`);
    }
  };

  // Random stock number for demo purposes
  const stockCount = Math.floor(Math.random() * 5) + 1;
  const isLowStock = stockCount <= 3;
  
  // Render stars for rating
  const renderRatingStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(<Star key={i} className="h-4 w-4 fill-current text-amber-400" />);
      } else if (i === fullStars + 1 && hasHalfStar) {
        stars.push(
          <span key={i} className="relative">
            <Star className="h-4 w-4 text-muted-foreground" />
            <Star className="h-4 w-4 fill-current text-amber-400 absolute top-0 left-0 overflow-hidden" style={{ clipPath: 'inset(0 50% 0 0)' }} />
          </span>
        );
      } else {
        stars.push(<Star key={i} className="h-4 w-4 text-muted-foreground" />);
      }
    }
    
    return stars;
  };
  
  if (!product) {
    return (
      <div className="container-custom py-16 text-center">
        <p>Product not found</p>
        <Link to="/shop" className="btn-primary mt-4">
          Back to Shop
        </Link>
      </div>
    );
  }
  
  // Calculate discount percentage for demo
  const originalPrice = Math.round(product.price * 1.2); // 20% higher for original price
  const discountPercentage = Math.round(((originalPrice - product.price) / originalPrice) * 100);
  
  return (
    <main className="py-8">
      <div className="container-custom">
        {/* Breadcrumbs */}
        <nav className="flex text-sm mb-8">
          <Link to="/" className="text-muted-foreground hover:text-clay-600 transition-colors">
            Home
          </Link>
          <ChevronRight className="mx-2 h-4 w-4 text-muted-foreground" />
          <Link to="/shop" className="text-muted-foreground hover:text-clay-600 transition-colors">
            Shop
          </Link>
          <ChevronRight className="mx-2 h-4 w-4 text-muted-foreground" />
          <span className="text-foreground font-medium">{product.name}</span>
        </nav>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <div>
            <div className="aspect-square overflow-hidden rounded-lg mb-4 bg-earth-50">
              <img 
                src={product.images[activeImage]} 
                alt={product.name}
                className="w-full h-full object-cover object-center product-animate"
              />
            </div>
            
            {/* Thumbnails */}
            <div className="grid grid-cols-4 gap-4">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setActiveImage(index)}
                  className={`aspect-square rounded-md overflow-hidden bg-earth-50 border-2 ${
                    activeImage === index ? 'border-clay-600' : 'border-transparent'
                  }`}
                >
                  <img 
                    src={image} 
                    alt={`${product.name} - view ${index + 1}`}
                    className="w-full h-full object-cover object-center"
                  />
                </button>
              ))}
            </div>
          </div>
          
          {/* Product Info */}
          <div>
            <h1 className="font-serif text-3xl font-medium product-animate">
              {product.name}
            </h1>
            
            <p className="text-xs text-muted-foreground mt-2 product-animate">
              Product ID: {product.id}
            </p>
            
            {/* Product Rating */}
            <div className="flex items-center mt-2 product-animate">
              <div className="flex">
                {renderRatingStars(4.5)} {/* Using a fixed rating of 4.5 for demo */}
              </div>
              <span className="ml-2 text-sm text-muted-foreground">
                4.5 (24 reviews)
              </span>
            </div>
            
            {/* Price with discounted price */}
            <div className="mt-3 product-animate flex items-center">
              <p className="text-2xl font-medium">
                ₹{product.price.toLocaleString()}
              </p>
              <p className="ml-2 text-sm text-muted-foreground line-through">
                ₹{originalPrice.toLocaleString()}
              </p>
              <span className="ml-2 text-xs px-2 py-1 bg-red-100 text-red-800 rounded-full">
                {discountPercentage}% OFF
              </span>
            </div>
            
            {/* Stock Message */}
            {isLowStock && (
              <div className="mt-2 flex items-center text-red-600 product-animate">
                <AlertCircle className="h-4 w-4 mr-1" />
                <p className="text-sm font-medium">Only {stockCount} left in stock!</p>
              </div>
            )}
            
            <p className="mt-4 text-muted-foreground product-animate">
              {product.description}
            </p>
            
            <div className="mt-6 pb-6 border-b border-border product-animate">
              <h3 className="font-medium mb-2">Material</h3>
              <p>{product.material}</p>
            </div>
            
            {product.dimensions && (
              <div className="mt-6 pb-6 border-b border-border product-animate">
                <h3 className="font-medium mb-2">Dimensions</h3>
                <p>
                  W: {product.dimensions.width}" × 
                  H: {product.dimensions.height}"
                  {product.dimensions.depth && ` × D: ${product.dimensions.depth}"`}
                </p>
              </div>
            )}
            
            {/* Quantity Selector */}
            <div className="mt-8 product-animate">
              <h3 className="font-medium mb-3">Quantity</h3>
              <div className="flex items-center space-x-4">
                <div className="flex items-center border border-input rounded-md">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-2 text-muted-foreground hover:text-foreground transition-colors"
                    aria-label="Decrease quantity"
                  >
                    <Minus size={16} />
                  </button>
                  <span className="w-12 text-center">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-2 text-muted-foreground hover:text-foreground transition-colors"
                    aria-label="Increase quantity"
                  >
                    <Plus size={16} />
                  </button>
                </div>
                
                <p className="text-sm text-muted-foreground">
                  {product.inStock ? 'In Stock' : 'Out of Stock'}
                </p>
              </div>
            </div>
            
            {/* Add to Cart */}
            <div className="mt-6 flex flex-col sm:flex-row gap-4 product-animate">
              <button
                onClick={handleAddToCart}
                className="btn-primary flex-1 justify-center"
                disabled={!product.inStock}
              >
                Add to Cart
              </button>
              
              <button className="flex items-center justify-center gap-2 py-3 px-6 border border-input rounded-md hover:bg-muted transition-colors">
                <Heart size={18} />
                <span>Save</span>
              </button>
              
              <button className="flex items-center justify-center p-3 border border-input rounded-md hover:bg-muted transition-colors sm:px-4">
                <Share size={18} />
                <span className="sr-only sm:not-sr-only sm:ml-2">Share</span>
              </button>
            </div>
            
            {/* Additional Info */}
            <div className="mt-8 product-animate">
              <h3 className="font-medium mb-4">Product Description</h3>
              <p className="text-muted-foreground">
                {product.fullDescription}
              </p>
            </div>
            
            {product.care && (
              <div className="mt-6 product-animate">
                <h3 className="font-medium mb-2">Care Instructions</h3>
                <ul className="list-disc pl-5 text-muted-foreground space-y-1">
                  {product.care.map((instruction, index) => (
                    <li key={index}>{instruction}</li>
                  ))}
                </ul>
              </div>
            )}
            
            {/* Customer Reviews Section */}
            <div className="mt-10 pt-6 border-t border-border product-animate">
              <h3 className="font-medium mb-4">Customer Reviews</h3>
              
              <div className="space-y-6">
                <div className="border-b border-border pb-4">
                  <div className="flex justify-between mb-2">
                    <div>
                      <p className="font-medium">Amit Sharma</p>
                      <div className="flex mt-1">
                        {renderRatingStars(5)}
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">3 weeks ago</p>
                  </div>
                  <p className="mt-2 text-muted-foreground">
                    Absolutely love the quality of this item! The craftsmanship is excellent
                    and it looks even better in person than in the photos.
                  </p>
                </div>
                
                <div className="border-b border-border pb-4">
                  <div className="flex justify-between mb-2">
                    <div>
                      <p className="font-medium">Priya Patel</p>
                      <div className="flex mt-1">
                        {renderRatingStars(4)}
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">1 month ago</p>
                  </div>
                  <p className="mt-2 text-muted-foreground">
                    Really well made and beautiful. Shipping was quick and everything arrived
                    in perfect condition. Would buy again!
                  </p>
                </div>
                
                <Link to="#" className="text-clay-600 hover:text-clay-800 transition-colors inline-block">
                  Read all 24 reviews
                </Link>
              </div>
            </div>
          </div>
        </div>
        
        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-20">
            <h2 className="font-serif text-2xl font-medium mb-8">You Might Also Like</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map(relatedProduct => (
                <ProductCard key={relatedProduct.id} product={relatedProduct} />
              ))}
            </div>
          </div>
        )}
      </div>
    </main>
  );
};

export default ProductDetailPage;
