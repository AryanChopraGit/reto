
import React from 'react';
import { Link } from 'react-router-dom';
import { Package, ChevronRight } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent } from '@/components/ui/card';

const OrdersPage: React.FC = () => {
  // Mock order data for demonstration
  const orders = [
    {
      id: "ORD-2025-1001",
      date: "April 2, 2025",
      total: 9299,
      status: "Delivered",
      items: [
        { id: "prod-01", name: "Handwoven Cotton Throw", quantity: 1, price: 2499 },
        { id: "prod-07", name: "Ceramic Vase Set", quantity: 1, price: 6800 }
      ]
    },
    {
      id: "ORD-2025-0897",
      date: "March 15, 2025",
      total: 5499,
      status: "Processing",
      items: [
        { id: "prod-04", name: "Handcarved Wooden Bowl", quantity: 1, price: 1899 },
        { id: "prod-02", name: "Macrame Wall Hanging", quantity: 1, price: 3600 }
      ]
    }
  ];

  return (
    <main className="py-12">
      <div className="container-custom max-w-4xl">
        <div className="flex items-center justify-between mb-8">
          <h1 className="font-serif text-3xl font-medium">My Orders</h1>
          <Link to="/account" className="text-clay-600 hover:text-clay-800 transition-colors">
            Back to Account
          </Link>
        </div>
        
        <Separator className="mb-8" />
        
        {orders.length > 0 ? (
          <div className="space-y-8">
            {orders.map(order => (
              <Card key={order.id} className="overflow-hidden">
                <div className="bg-muted px-6 py-4 flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                  <div>
                    <p className="font-medium">{order.id}</p>
                    <p className="text-sm text-muted-foreground">Placed on {order.date}</p>
                  </div>
                  <div className="flex gap-3 items-center">
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      order.status === "Delivered" 
                        ? "bg-green-100 text-green-800" 
                        : "bg-amber-100 text-amber-800"
                    }`}>
                      {order.status}
                    </span>
                    <span className="font-medium">₹{order.total.toLocaleString()}</span>
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {order.items.map(item => (
                      <div key={item.id} className="flex justify-between items-center">
                        <div className="flex gap-2">
                          <span className="text-sm text-muted-foreground">{item.quantity}x</span>
                          <span>{item.name}</span>
                        </div>
                        <span>₹{item.price.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex justify-end mt-6">
                    <Link 
                      to={`/account/orders/${order.id}`} 
                      className="flex items-center text-clay-600 hover:text-clay-800 transition-colors"
                    >
                      View Order Details
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center py-16">
            <CardContent>
              <Package className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-medium">No orders yet</h3>
              <p className="mt-2 text-muted-foreground max-w-md mx-auto">
                When you place an order, it will appear here for you to track.
              </p>
              <Link 
                to="/shop" 
                className="btn-primary inline-block mt-6"
              >
                Start Shopping
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </main>
  );
};

export default OrdersPage;
