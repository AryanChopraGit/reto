
import React from 'react';
import { Separator } from '@/components/ui/separator';
import { Truck, RotateCcw, Clock, Shield } from 'lucide-react';

const ShippingReturnsPage: React.FC = () => {
  return (
    <main className="py-12">
      <div className="container-custom max-w-3xl">
        <h1 className="font-serif text-3xl font-medium mb-6">Shipping & Returns</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <div className="bg-earth-50 p-6 rounded-lg flex flex-col items-center text-center">
            <Truck className="h-10 w-10 text-clay-600 mb-4" />
            <h2 className="text-xl font-medium mb-2">Fast Shipping</h2>
            <p className="text-muted-foreground">
              We dispatch orders within 24-48 hours and deliver across India.
            </p>
          </div>
          
          <div className="bg-earth-50 p-6 rounded-lg flex flex-col items-center text-center">
            <RotateCcw className="h-10 w-10 text-clay-600 mb-4" />
            <h2 className="text-xl font-medium mb-2">Easy Returns</h2>
            <p className="text-muted-foreground">
              Return within 30 days of delivery for a full refund.
            </p>
          </div>
        </div>
        
        <section className="mb-10">
          <h2 className="text-2xl font-medium mb-4">Shipping Policy</h2>
          <Separator className="mb-6" />
          
          <div className="space-y-6">
            <div>
              <h3 className="font-medium text-lg mb-2">Processing Time</h3>
              <p className="text-muted-foreground">
                All orders are processed within 1-2 business days. Orders placed on weekends or 
                holidays will be processed on the next business day.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium text-lg mb-2">Shipping Methods & Delivery Time</h3>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-clay-600 mt-0.5" />
                  <div>
                    <p className="font-medium">Standard Shipping (3-5 business days)</p>
                    <p className="text-sm text-muted-foreground">
                      Free for orders over ₹2,000<br />
                      ₹199 for orders under ₹2,000
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <Truck className="h-5 w-5 text-clay-600 mt-0.5" />
                  <div>
                    <p className="font-medium">Express Shipping (1-2 business days)</p>
                    <p className="text-sm text-muted-foreground">
                      ₹399 for all orders<br />
                      Available only for select locations
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-medium text-lg mb-2">Shipping to Remote Areas</h3>
              <p className="text-muted-foreground">
                For remote areas, delivery may take an additional 2-3 days. We'll notify you 
                if your location falls under this category.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium text-lg mb-2">International Shipping</h3>
              <p className="text-muted-foreground">
                We currently ship to select countries. International shipping rates and 
                delivery timeframes vary by destination. Customs fees and import duties 
                may apply and are the responsibility of the recipient.
              </p>
            </div>
          </div>
        </section>
        
        <section>
          <h2 className="text-2xl font-medium mb-4">Returns & Refunds</h2>
          <Separator className="mb-6" />
          
          <div className="space-y-6">
            <div>
              <h3 className="font-medium text-lg mb-2">Return Policy</h3>
              <p className="text-muted-foreground">
                We accept returns within 30 days of delivery. Items must be unused, undamaged, 
                and in their original packaging. Custom or personalized items cannot be returned 
                unless they are defective.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium text-lg mb-2">How to Return</h3>
              <ol className="list-decimal pl-5 text-muted-foreground space-y-2">
                <li>Contact our customer service team at returns@handcrafted.example.com to request a return.</li>
                <li>You'll receive a return authorization and instructions.</li>
                <li>Pack the item securely in its original packaging if possible.</li>
                <li>Ship the item back to us using a tracked shipping method.</li>
              </ol>
            </div>
            
            <div>
              <h3 className="font-medium text-lg mb-2">Refund Process</h3>
              <p className="text-muted-foreground">
                Once we receive and inspect the returned item, we'll notify you about the status 
                of your refund. If approved, your refund will be processed to the original method 
                of payment within 5-7 business days.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium text-lg mb-2">Damaged or Defective Items</h3>
              <p className="text-muted-foreground">
                If you receive a damaged or defective item, please contact us within 48 hours of 
                delivery with photos of the damage. We'll arrange for a replacement or refund.
              </p>
            </div>
          </div>
        </section>
        
        <div className="flex justify-center my-12">
          <div className="flex items-center gap-2 text-clay-600">
            <Shield className="h-5 w-5" />
            <span className="font-medium">100% Satisfaction Guarantee</span>
          </div>
        </div>
      </div>
    </main>
  );
};

export default ShippingReturnsPage;
