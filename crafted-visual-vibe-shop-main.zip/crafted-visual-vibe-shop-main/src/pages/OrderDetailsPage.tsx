
import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { ChevronLeft, Package, Truck, CheckCircle } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent } from '@/components/ui/card';

const OrderDetailsPage: React.FC = () => {
  const { orderId } = useParams<{ orderId: string }>();
  
  // Mock order data - in a real application, this would come from an API
  const order = {
    id: orderId || "ORD-2025-1001",
    date: "April 2, 2025",
    total: 9299,
    subtotal: 8899,
    shipping: 400,
    status: "Delivered",
    paymentMethod: "Cash on Delivery",
    shippingAddress: {
      name: "John Doe",
      line1: "123 Artisan Lane",
      line2: "Apartment 4B",
      city: "Bangalore",
      state: "Karnataka",
      pincode: "560001",
      country: "India"
    },
    tracking: {
      number: "IND7891234567",
      url: "#",
      carrier: "ExpressDelivery",
      estimatedDelivery: "April 5, 2025",
      events: [
        { date: "April 2, 2025", time: "11:30 AM", status: "Order Placed", location: "Online" },
        { date: "April 3, 2025", time: "10:15 AM", status: "Processing", location: "Delhi Warehouse" },
        { date: "April 3, 2025", time: "6:45 PM", status: "Shipped", location: "Delhi" },
        { date: "April 4, 2025", time: "3:20 PM", status: "In Transit", location: "Mumbai Hub" },
        { date: "April 5, 2025", time: "11:05 AM", status: "Delivered", location: "Bangalore" }
      ]
    },
    items: [
      { id: "prod-01", name: "Handwoven Cotton Throw", quantity: 1, price: 2499, image: "/images/products/throw.jpg" },
      { id: "prod-07", name: "Ceramic Vase Set", quantity: 1, price: 6800, image: "/images/products/vase-set.jpg" }
    ]
  };

  return (
    <main className="py-12">
      <div className="container-custom max-w-4xl">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Link to="/account/orders" className="text-clay-600 hover:text-clay-800 transition-colors inline-flex items-center mr-4">
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back to Orders
            </Link>
            <h1 className="font-serif text-2xl font-medium">Order #{order.id}</h1>
          </div>
          <span className={`px-3 py-1 text-sm rounded-full ${
            order.status === "Delivered" 
              ? "bg-green-100 text-green-800" 
              : "bg-amber-100 text-amber-800"
          }`}>
            {order.status}
          </span>
        </div>
        
        <Separator className="mb-8" />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Order Summary & Items */}
          <div className="md:col-span-2">
            <Card>
              <CardContent className="p-6">
                <h2 className="text-lg font-medium mb-4">Order Summary</h2>
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Order Date</span>
                    <span>{order.date}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Payment Method</span>
                    <span>{order.paymentMethod}</span>
                  </div>
                </div>
                
                <Separator className="my-4" />
                
                <h3 className="text-md font-medium mb-4">Items</h3>
                <div className="space-y-6">
                  {order.items.map(item => (
                    <div key={item.id} className="flex gap-4">
                      <div className="h-20 w-20 bg-muted rounded-md flex-shrink-0 overflow-hidden">
                        <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                      </div>
                      <div className="flex-1">
                        <Link to={`/product/${item.id}`} className="font-medium hover:text-clay-600 transition-colors">
                          {item.name}
                        </Link>
                        <div className="flex justify-between mt-2">
                          <div className="text-sm text-muted-foreground">
                            Qty: {item.quantity}
                          </div>
                          <div className="font-medium">
                            ₹{item.price.toLocaleString()}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <Separator className="my-4" />
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>₹{order.subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Shipping</span>
                    <span>₹{order.shipping.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between font-medium mt-2 pt-2 border-t">
                    <span>Total</span>
                    <span>₹{order.total.toLocaleString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Shipping & Tracking */}
          <div>
            <Card className="mb-6">
              <CardContent className="p-6">
                <h2 className="text-lg font-medium mb-4">Shipping Address</h2>
                <div className="text-sm">
                  <p className="font-medium">{order.shippingAddress.name}</p>
                  <p>{order.shippingAddress.line1}</p>
                  {order.shippingAddress.line2 && <p>{order.shippingAddress.line2}</p>}
                  <p>{order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.pincode}</p>
                  <p>{order.shippingAddress.country}</p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h2 className="text-lg font-medium mb-4">Tracking Information</h2>
                <div className="text-sm mb-4">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Carrier</span>
                    <span>{order.tracking.carrier}</span>
                  </div>
                  <div className="flex justify-between mt-1">
                    <span className="text-muted-foreground">Tracking Number</span>
                    <a href={order.tracking.url} className="text-clay-600 hover:underline">{order.tracking.number}</a>
                  </div>
                  <div className="flex justify-between mt-1">
                    <span className="text-muted-foreground">Est. Delivery</span>
                    <span>{order.tracking.estimatedDelivery}</span>
                  </div>
                </div>
                
                <div className="relative">
                  <div className="absolute left-3 top-0 bottom-0 w-0.5 bg-muted-foreground/30 z-0"></div>
                  <div className="space-y-4 relative z-10">
                    {order.tracking.events.map((event, index) => (
                      <div key={index} className="flex items-start">
                        <div className={`mt-1 h-6 w-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                          index === 0 ? "bg-clay-600 text-white" : "bg-muted border border-muted-foreground/30"
                        }`}>
                          {index === 0 && <CheckCircle className="h-4 w-4" />}
                        </div>
                        <div className="ml-3">
                          <p className="font-medium">{event.status}</p>
                          <p className="text-xs text-muted-foreground">
                            {event.date} at {event.time} • {event.location}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  );
};

export default OrderDetailsPage;
